package com.cts.bookShopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.userRegistration;
import com.cts.bookShopping.dao.RegisterationDAO;


@Service("registrationService")
@Transactional(propagation = Propagation.SUPPORTS)
public class RegisterationServiceImpl implements RegisterationService{

	@Autowired
	private RegisterationDAO registrationDAO;
	@Override
	public String setUserDetails(userRegistration userregistration) {
		
		System.out.println(userregistration);
		// TODO Auto-generated method stub
		return registrationDAO.setUserDetails(userregistration);
	}

}
