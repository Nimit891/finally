package com.cts.bookShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.Category;
import com.cts.bookShopping.dao.CategoryDAO;

@Service("categoryService")
@Transactional(propagation = Propagation.SUPPORTS)
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	private CategoryDAO categoryDAO;
	public List<Category> getCategoryName() {
		// TODO Auto-generated method stub
		return categoryDAO.getCategoryName();
	}

	@Override
	public List<Category> getAllCategory() {
		// TODO Auto-generated method stub
		return categoryDAO.getAllCategory();
	}

	@Override
	public String insertCategory(Category cat) {
		// TODO Auto-generated method stub
		return categoryDAO.insertCategory(cat);
	}

	@Override
	public Category viewCategoryByName(String categoryName) {
		// TODO Auto-generated method stub
		return categoryDAO.viewCategoryByName(categoryName);
	}
	

}
