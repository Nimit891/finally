package com.cts.bookShopping.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.userRegistration;
//@Repository("productDAO")
@Repository("registrationDAO")
public class RegisterationDAOImpl implements RegisterationDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional
	public String setUserDetails(userRegistration userregisteration) {
		// TODO Auto-generated method stub
		Session session = null;
		System.out.println(userregisteration);
		try {
		session = sessionFactory.getCurrentSession();
		session.save(userregisteration);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		
		return null;
	}

}