package com.cts.bookShopping.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.Category;
import com.cts.bookShopping.service.BooksService;
import com.cts.bookShopping.service.CategoryService;




@Controller
public class BooksController {
	@Autowired
	BooksService booksService;
	
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping("adminHomepage.html")
	public String getBooks(){
		return "adminHomepage";
	}
	
	
	
	
	
//	@RequestMapping("addproduct.html")
//	public String addBooks(){
//		return "addproduct";
//	}
	
	
	@RequestMapping(value="booksadded.html",method = RequestMethod.POST)
	public String addBook(@ModelAttribute Books books,HttpSession httpSession,HttpServletRequest httpServletRequest){
		//session
		
		ModelAndView modelAndView = new ModelAndView();
		
		books.catName = httpServletRequest.getParameter("catName");
		if("true".equals(booksService.insertBook(books)))
		{
			System.out.println(books);
			return "addproduct";
		}
		else
		{
			return null;
		}
		
	}
	@GetMapping(value="addproduct.html")
	public ModelAndView viewCategory(@ModelAttribute Category category){
		ModelAndView modelAndView = new ModelAndView();
		List<Category> list = categoryService.getAllCategory();
		System.out.println("hello"+list);
		modelAndView.addObject("category", list);
		modelAndView.setViewName("addproduct");
		return modelAndView;
	}
	@GetMapping(value="editBook.html")
	public ModelAndView getDeleteProduct(){
		ModelAndView modelAndView = new ModelAndView();

		List<Books> list = booksService.getAllBook();
		System.out.println(list);
		modelAndView.addObject("books",list);
		
//		
	//	modelAndView.setViewName("deleteBook");
		return modelAndView;
	}
	@RequestMapping(value="AdminDeleteBook.html")
	public ModelAndView getDeleteProduct(@RequestParam("id") String id,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		String st = booksService.deleteBook(id);
		if("true".equals(st))
		{
			mav.setViewName("AdminDeleteBook");
				
		}
		return mav;
	}
	
	@RequestMapping("updateBook.html")
	public ModelAndView updateBook(@ModelAttribute Books books, @RequestParam("id") String id){
		ModelAndView modelAndView = new ModelAndView();
		Books book= booksService.getBookById(id);
		System.out.println("in get");
		/*List<Category> list = categoryService.getAllCategory();*/
		modelAndView.addObject("books",book);
		//modelAndView.addObject("book",new Book());
		/*modelAndView.addObject("listcat",list);*/	
		modelAndView.setViewName("updateBook");
		return modelAndView;
	}
	
	@RequestMapping(value="updateBook1.html", method=RequestMethod.POST)
	public ModelAndView booksUpdate(@ModelAttribute Books books){
		ModelAndView modelAndView = new ModelAndView();
		System.out.println("in update");
		booksService.updateBook(books);
		modelAndView.setViewName("booksUpdated");
		return modelAndView;
	}
	@RequestMapping(value="search.html", method=RequestMethod.POST)
	public ModelAndView getViewBook(@RequestParam("search") String name,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
	Books book= booksService.getBookByName(name);
		if(book==null){
			List<Books> list=booksService.getAllBook();
			mav.addObject("books",list);
			mav.setViewName("home");
		}
		else{
		mav.addObject("books",book);
		mav.setViewName("search");
		}
		return mav;
	}
}
